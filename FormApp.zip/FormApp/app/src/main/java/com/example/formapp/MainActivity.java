package com.example.formapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText loginEditText;
    private EditText passwordEditText;
    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private Button submitButton;

    private static final String CORRECT_LOGIN = "BarSzym";
    private static final String CORRECT_PASSWORD = "qwerty123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginEditText = findViewById(R.id.loginEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        firstNameEditText = findViewById(R.id.loginEditText);
        lastNameEditText = findViewById(R.id.passwordEditText);
        submitButton = findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = loginEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (CORRECT_LOGIN.equals(login) && CORRECT_PASSWORD.equals(password)) {
                    String firstName = firstNameEditText.getText().toString();
                    String lastName = lastNameEditText.getText().toString();

                    // Logowanie danych
                    Log.d("FormApp", "First Name: " + firstName);
                    Log.d("FormApp", "Last Name: " + lastName);

                    // Przechowywanie danych w zmiennych
                    saveData(firstName, lastName);

                    // Otwieranie strony pkobp.pl
                    openWebPage("https://www.pkobp.pl/");
                } else {
                    Toast.makeText(MainActivity.this, "Błędne dane logowania", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void saveData(String firstName, String lastName) {
        Log.d("FormApp", "Data saved: " + firstName + " " + lastName);
    }

    private void openWebPage(String url) {
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}
